Empty application. Add your own sources.
